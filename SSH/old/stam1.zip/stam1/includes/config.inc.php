<?php

$db_host = 'localhost';
$db_user = 'stackman';
$db_pass = 'manstack';
$db_base = 'stackman';

