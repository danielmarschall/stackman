<?php

require __DIR__ . '/config.inc.php';

if (!mysql_connect($db_host, $db_user, $db_pass)) {
	echo "MySQL connect error\n";
	exit(1);
}

if (!mysql_select_db($db_base)) {
	echo "MySQL DB select error\n";
	mysql_close();
	exit(1);
}

function trennen() {
	mysql_close();
}

register_shutdown_function('trennen');
